//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Server1.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_Server1TYPE                 129
#define IDD_DLG_CLIENT_CANVAS           130
#define IDD_DLG_TEXT                    131
#define IDD_DLG_PARAM_CANFRAME          132
#define IDD_DLG_BUSSTAT                 133
#define IDD_DLG_NUMBER                  134
#define IDC_BTN_CANVAS_INIT             1000
#define IDC_BTN_CANVAS_CLOSE            1001
#define IDC_BTN_LOAD_CONFIG             1003
#define IDC_BTN_SAVE_CONFIG             1004
#define IDC_BTN_CONNECT                 1005
#define IDC_BTN_START_LOG               1006
#define IDC_BTN_STOP_LOG                1007
#define IDC_BTN_WRITE_LOG               1008
#define IDC_BTN_LOAD_DLL                1009
#define IDC_BTN_UNLOAD_DLL              1010
#define IDC_BTN_START_TX                1011
#define IDC_BTN_STOP_TX                 1012
#define IDC_BTN_SEND                    1013
#define IDC_BTN_NET_STAT                1014
#define IDC_STATIC_HELPTEXT             1015
#define IDC_EDIT1                       1016
#define IDC_BTN_DB_IMPORT               1016
#define IDC_EDIT_CANID                  1017
#define IDC_BTN_INFO_MSG                1017
#define IDC_CHK_EXTENDED                1018
#define IDC_BTN_SAVE_CONFIG_AS          1018
#define IDC_CHK_RTR                     1019
#define IDC_BTN_TXBLK_COUNT             1019
#define IDC_EDIT_DLC                    1020
#define IDC_BTN_TXBLK_CLEAR             1020
#define IDC_EDIT_DATA1                  1021
#define IDC_BTN_LOGBLK_COUNT            1021
#define IDC_EDIT_DATA2                  1022
#define IDC_BTN_LOGBLK_REMOVE           1022
#define IDC_EDIT_GETNUM                 1022
#define IDC_EDIT_DATA3                  1023
#define IDC_BTN_LOGBLK_CLEAR            1023
#define IDC_EDIT_DATA4                  1024
#define IDC_EDIT_RX_COUNT               1024
#define IDC_EDIT_DATA5                  1025
#define IDC_LIST_RX_DATA                1025
#define IDC_EDIT_DATA6                  1026
#define IDC_EDIT_RX_COUNT2              1026
#define IDC_EDIT_UNIQUE_ID              1026
#define IDC_EDIT_DATA7                  1027
#define IDC_BTN_HANDLERS_MOD            1027
#define IDC_EDIT_DATA8                  1028
#define IDC_BTN_UNLOAD_DLL2             1028
#define IDC_BTN_SEND_KEYVAL             1028
#define IDC_EDIT_CHANNEL                1029
#define ID_DIALOGS_CANVAS               32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
